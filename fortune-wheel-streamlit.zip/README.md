# 🎡 Fortune Wheel — Streamlit

A deployable Streamlit app for a weighted fortune wheel with smooth animation, fixed pointer, and labels that stay inside their slices.

## Local run
```bash
pip install -r requirements.txt
streamlit run app.py
```

## Deploy to Streamlit Community Cloud
1. Push these files to a public GitHub repo (`app.py`, `requirements.txt`).
2. Go to https://share.streamlit.io/ → **New app**.
3. Pick your repo, branch (e.g., `main`), and path `app.py` → **Deploy**.

No extra config needed. You can upload a CSV with columns `Name` and optional `Weight`.
